# wizards/__init__.py
from . import jabin_loyalty_adjust_wizard
