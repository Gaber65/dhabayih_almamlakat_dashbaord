from odoo import http
from odoo.http import request
from odoo.addons.web.controllers.main import ensure_db
from odoo.addons.jabin_core import ResponseBuilder


class DashboardController(http.Controller):

    @http.route('/jabin_dashboard/data',  type="http",
        auth="public",
        methods=["POST"],
        csrf=False,
    )
    def get_dashboard_data(self, **kwargs):
        """Get all dashboard data"""
        ensure_db()

        # Get the dashboard service
        service = request.env['jabin.dashboard.service'].sudo()

        # Get all dashboard data
        data = service.get_dashboard_data()

        return ResponseBuilder.http_success(
            data=data,
            message="Dashboard loaded successfully"
        )